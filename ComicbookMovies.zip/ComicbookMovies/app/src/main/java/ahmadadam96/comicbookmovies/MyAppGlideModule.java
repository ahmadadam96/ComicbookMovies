package ahmadadam96.comicbookmovies;

/**
 * Created by ahmad on 10/25/2017.
 */

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

@GlideModule
public final class MyAppGlideModule extends AppGlideModule {}