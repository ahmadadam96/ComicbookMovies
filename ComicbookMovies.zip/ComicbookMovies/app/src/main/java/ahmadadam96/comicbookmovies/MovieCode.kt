package ahmadadam96.comicbookmovies

/**
 * Created by ahmad on 2017-03-19.
 */

class MovieCode internal constructor(val code: String, val universe: String)
